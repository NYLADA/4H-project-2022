function playSound(sound1) {
  var song1 = document.getElementById(sound1);
  song1.volume = 1;    // setting the volume to 25% because the sound is loud
  if( song1.paused) { // if song1 is paused
    song1.play();
  } else {
    song1.pause();

  }
}
