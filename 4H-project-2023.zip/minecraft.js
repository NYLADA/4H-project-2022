function playSound(sound2) {
  var song1 = document.getElementById(sound2);
  song1.volume = 1; 
  if (song1.paused) {  
    song1.play();
  } else {
    song1.pause();
  }
}