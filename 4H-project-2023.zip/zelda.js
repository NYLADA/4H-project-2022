function playSound(sound) {
  var song1 = document.getElementById(sound);
  song1.volume = 0.5; // setting the volume to 50% because the sound is loud
  if (song1.paused) {  
    song1.play();
  } else {
    song1.pause();
  }
}